"use client";

import { useMemo } from "react";
import { usePathname } from "next/navigation";

import NavigationDesktop from "./NavigationDesktop";
import NavigationMobile from "./NavigationMobile";
import NavigationPopover from "./NavigationPopover";
import { navigationItems } from "./navigation.constants";
import { useNavigation } from "./NavigationProvider";

/**
 * ============================================================================
 * MISTI CUY
 * ----------------------------------------------------------------------------
 * Navigation System
 *
 * Punto de entrada oficial del sistema de navegación.
 *
 * Obtiene automáticamente el título de la página
 * según la ruta actual.
 * ============================================================================
 */

export default function Navigation() {
  const pathname = usePathname();

  const {
    drawerOpen,
    openDrawer,
    closeDrawer,
  } = useNavigation();

  /**
   * Determina automáticamente si debe mostrarse
   * el botón para volver.
   */
  const showBackButton = useMemo(() => {
    return pathname !== "/";
  }, [pathname]);

  /**
   * Obtiene la página actual desde la configuración
   * oficial de navegación.
   */
  const currentPage = useMemo(() => {
    return (
      navigationItems.find((item) => item.href === pathname) ??
      navigationItems[0]
    );
  }, [pathname]);

  return (
    <>
      {/* Desktop */}
      <NavigationDesktop />

      {/* Mobile */}
      <NavigationMobile
        title={currentPage.title}
        showBackButton={showBackButton}
        onMenuClick={openDrawer}
      />

      {/* Popover */}
      <NavigationPopover
        open={drawerOpen}
        currentPath={pathname}
        onClose={closeDrawer}
      />
    </>
  );
}