/**
 * ============================================================================
 * MISTI CUY
 * ----------------------------------------------------------------------------
 * Navigation System
 *
 * Tipos oficiales del sistema de navegación.
 * ============================================================================
 */

/**
 * Item del menú principal.
 */
export interface NavigationItem {
  id: string;
  label: string;
  title: string;
  href: string;
  isEnabled: boolean;
}

/**
 * Props del Header Mobile.
 */
export interface NavigationMobileProps {
  title: string;
  showBackButton?: boolean;
  onMenuClick: () => void;
}

/**
 * Contexto del sistema de navegación.
 */
export interface NavigationProviderValue {
  drawerOpen: boolean;

  openDrawer: () => void;
  closeDrawer: () => void;
  toggleDrawer: () => void;

  menuButtonRef: React.RefObject<HTMLDivElement | null>;

  menuButtonRect: DOMRect | null;
}