"use client";

import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

export default function HeroScrollIndicator() {
  const handleClick = () => {
    document
      .getElementById("story")
      ?.scrollIntoView({
        behavior: "smooth",
      });
  };

  return (
    <motion.button
      type="button"
      onClick={handleClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{
        opacity: 1,
        y: [0, 10, 0],
      }}
      transition={{
        opacity: {
          duration: 0.8,
        },
        y: {
          duration: 1.8,
          repeat: Infinity,
          ease: "easeInOut",
        },
      }}
      className="
        absolute
        bottom-10
        left-1/2
        z-20
        -translate-x-1/2
        rounded-full
        border
        border-white/10
        bg-white/5
        p-3
        backdrop-blur-xl
        transition-all
        duration-300
        hover:border-primary
        hover:bg-white/10
      "
      aria-label="Ir a la historia"
    >
      <ChevronDown
        size={24}
        className="text-white"
      />
    </motion.button>
  );
}