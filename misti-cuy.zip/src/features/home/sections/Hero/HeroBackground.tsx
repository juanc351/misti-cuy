import Image from "next/image";

export default function HeroBackground() {
  return (
    <div className="absolute inset-0">
      <Image
        src="/assets/images/hero/hero-home.png"
        alt="Misti Cuy"
        fill
        priority
        quality={90}
        className="object-cover object-center"
      />

      {/* Overlay principal */}
      <div className="absolute inset-0 bg-black/45" />

      {/* Gradiente superior */}
      <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-black via-black/40 to-transparent" />

      {/* Gradiente inferior */}
      <div className="absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-black via-black/70 to-transparent" />

      {/* Oscurecer ligeramente el lado izquierdo */}
      <div className="absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-black/50 via-black/20 to-transparent" />
    </div>
  );
}