export default function HeroContent() {
  return (
    <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-col items-center px-6 text-center">
      <span className="mb-6 text-sm font-semibold uppercase tracking-[0.4em] text-primary">
        MISTI CUY
      </span>

      <h1 className="max-w-5xl text-5xl font-black leading-tight md:text-7xl">
        ESTO RECIÉN
        <br />
        COMIENZA
      </h1>

      <p className="mt-8 max-w-2xl text-lg leading-8 text-secondary">
        Estamos construyendo una granja tecnificada desde cero y
        documentaremos cada paso del camino.
      </p>

      <button
        type="button"
        className="
          mt-12
          rounded-2xl
          border
          border-primary
          px-8
          py-4
          text-lg
          font-semibold
          transition-all
          duration-300
          hover:bg-primary
          hover:text-black
        "
      >
        Comenzar la historia
      </button>
    </div>
  );
}