import Image from "next/image";

import type { Story } from "../../types/story.types";

interface StorySceneProps {
  story: Story;
}

export default function StoryScene({
  story,
}: StorySceneProps) {
  const imageFirst = story.layout === "left";

  return (
    <section className="min-h-screen snap-start">
      <div className="mx-auto grid min-h-screen max-w-7xl grid-cols-1 items-center gap-16 px-8 py-20 lg:grid-cols-2">
        {imageFirst && (
          <StoryImage
            image={story.image}
            title={story.title}
          />
        )}

        <StoryContent story={story} />

        {!imageFirst && (
          <StoryImage
            image={story.image}
            title={story.title}
          />
        )}
      </div>
    </section>
  );
}

interface StoryImageProps {
  image: string;
  title: string;
}

function StoryImage({
  image,
  title,
}: StoryImageProps) {
  return (
    <div className="relative aspect-[4/5] overflow-hidden rounded-3xl">
      <Image
        src={image}
        alt={title}
        fill
        className="object-cover"
      />
    </div>
  );
}

interface StoryContentProps {
  story: Story;
}

function StoryContent({
  story,
}: StoryContentProps) {
  return (
    <div className="space-y-6">
      <span className="text-sm font-semibold uppercase tracking-[0.3em] text-primary">
        Capítulo {story.chapter}
      </span>

      <h2 className="text-5xl font-bold">
        {story.title}
      </h2>

      <p className="text-lg leading-8">
        {story.description}
      </p>

      <p className="text-lg italic">
        {story.conclusion}
      </p>
    </div>
  );
}